import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.swing.*;

public class PropertyGenerator {
	
	public static void log(String line){
		System.out.println(line);
	}
	
	public static String getRandAddress(){
		Random addressIndex = new Random();
		int randomLine = (addressIndex.nextInt(1000)) + 1;
		String fileName = "Random Addresses.txt";
	    int counter = 0;

	    // This will reference one line at a time
	    String line = null;
	    FileReader fileReader = null;
	    String resultAddr = "";
	    try {
	        // FileReader reads text files in the default encoding.
	        fileReader = new FileReader(fileName);

	        // Always wrap FileReader in BufferedReader.
	        BufferedReader bufferedReader = new BufferedReader(fileReader);

	        while((line = bufferedReader.readLine()) != null) {
	            counter++;
	            if(counter == randomLine) {
	               resultAddr = line;
	            }
	        }   
	        bufferedReader.close();
	    }
	    catch(FileNotFoundException ex) {
	        System.out.println( "Unable to open file '" + fileName + "'");                
	    }
	    catch(IOException ex) {
	        System.out.println("Error reading file '" + fileName + "'");                  
	        // Or we could just do this: 
	        // ex.printStackTrace();
	    }
	    return resultAddr;
	}
	
	public static String[] removeElement(String[] original, int element){
	    String[] n = new String[original.length - 1];
	    System.arraycopy(original, 0, n, 0, element );
	    System.arraycopy(original, element+1, n, element, original.length - element-1);
	    return n;
	}
	
	public static String pickRandom(String[] array) {
		int randItem = 0;
		String[] tempArray = array;
		String finalStr= "";
		Random item = new Random();
		Random randSize = new Random();
		int numRandItems = randSize.nextInt(array.length);
		for(int i=0; i<numRandItems; i++){
			randItem = item.nextInt(tempArray.length);
			if(i==0){
				finalStr = tempArray[randItem];
			}
			else{
				finalStr = finalStr + ", " + tempArray[randItem];
			}
			tempArray = removeElement(tempArray, randItem);
		}
		if (finalStr == ""){
			return "None";
		}
		else{
			return finalStr;
		}
	}
	
	public static String generateListing(String[] amenities, String[] roomTypes, String[] propertyTypes){
		DecimalFormat coordinateFormat = new DecimalFormat("0.00000");
		DecimalFormat ratingFormat = new DecimalFormat("0.0");
		DecimalFormat priceFormat = new DecimalFormat("0.00");
		Random rn = new Random();
		// x-coord: +/-90, 5 dec places
		// y-coord: +/-180, 5 dec places
		// availability
		// rating, propertyType, roomType, bedrooms, washrooms, amenities, price, address, coordinates, available?, availability
		// l_address, l_propertyType, l_availability (the values should be capitalized, btw), l_date, l_price, l_washrooms, l_bedrooms, l_postalCode (tbh, just set this to "M7G9H4" for everything), l_rating, l_longitude (set this all to 90.00000), l_lattitude (set this all to 100.00000), u_id (set this all to 1), l_amenities
		//id will be stamped in main
		double ratingDoub = (rn.nextInt(40)+10);
		ratingDoub /= 10;
		String rating = ratingFormat.format(ratingDoub);
		String propertyType = propertyTypes[rn.nextInt(propertyTypes.length)];
		String roomType = roomTypes[rn.nextInt(roomTypes.length)];
		String bedrooms = Integer.toString(rn.nextInt(16)+1);
		double[] half = {0, 0.5};
		String washrooms = Double.toString(rn.nextInt(16)+1+half[rn.nextInt(2)]);
		String amenitiesRand = pickRandom(amenities);
		double priceDoub = (rn.nextInt(15001)/100);
		String price = priceFormat.format(priceDoub);
		String address = getRandAddress();
		double dX_coord = (rn.nextInt(18000001)-9000000);
		double dY_coord = (rn.nextInt(36000001)-18000000);
		dX_coord /= 100000;
		dY_coord /= 100000;
		String x_coord = coordinateFormat.format(dX_coord);
		String y_coord = coordinateFormat.format(dY_coord);
		Boolean bAvailable = getRandomBiasedBoolean(70);
		String available = "";
		String availability = "";
		if (bAvailable){
			available = "AVAILABLE";
			availability = availability(rn.nextInt(10)+1);
		}
		else{
			available = "NOT AVAILABLE";
			availability = availability(0);
		}
		//l_id, l_address, l_propertyType, l_roomType, l_availability, l_date, l_price, l_washrooms, l_bedrooms, 
		//l_postalCode (all M7G9H4), l_rating, l_longitude, l_lattitude, u_id (all 1), l_amenities
		String generatedListing = address + ", " + propertyType + ", " + roomType + ", " + available  + 
				", " + "( " + availability + " )"  + ", " + price  + ", " + washrooms  + ", " + bedrooms + 
				", " + "M7G9H4" + ", " + rating + ", " + y_coord  + ", " + x_coord  + ", " + "1" + ", " + "( " + 
				amenitiesRand + " )";
		return generatedListing;
	}
	
	
	public static String[] appendToFront(String object, String[] array){
		String[] oldArray = array;
	    String[] newArray = new String[oldArray.length + 1];
	    newArray[0] = object;
	    System.arraycopy(oldArray, 0, newArray, 1, oldArray.length);
	    return newArray;
	}
	
	
    public static int randBetween(int start, int end) {
        return start + (int)Math.round(Math.random() * (end - start));
    }
    
	public static boolean getRandomBiasedBoolean(int truePossibility){
		Random rn = new Random();
		return (rn.nextInt(100)) < truePossibility;
	}
	
	public static String availability(int numDates){
		if (numDates == 0){
			return "";
		}
		int thisYear = Calendar.getInstance().get(Calendar.YEAR);
		int thisMonth = Calendar.getInstance().get(Calendar.MONTH);
		thisMonth++; // java months are 0-11, not 1-12
		int thisDay = Calendar.getInstance().get(Calendar.DATE);
        SimpleDateFormat dfDateTime  = new SimpleDateFormat("yyyy-MM-dd");
        int year = 0;// Here you can set Range of years you need
        int month = 0;
        int day = 0;
        String randomDate = "";
        Random rn = new Random();
        GregorianCalendar gc = new GregorianCalendar(year, month, 1);

        Set<String> availDateSet = new HashSet<String>();
        //availDateSet.add(3);
        for(int i=0; i<numDates; i++){
        	year = randBetween(thisYear, thisYear+2); //Year available can be 2 years in advance
        	if(year == thisYear){
        		month = randBetween(thisMonth-1, 11);
        		day = randBetween(thisDay, gc.getActualMaximum(gc.DAY_OF_MONTH));
        	}
        	else{
        		month = randBetween(0, 11);
        		day = randBetween(1, gc.getActualMaximum(gc.DAY_OF_MONTH));
        	}

        	gc.set(year, month, day);
        	randomDate = dfDateTime.format(gc.getTime());
        	availDateSet.add(randomDate);
        	for(int j=0; j<rn.nextInt(31); j++){//intervals
        		gc.add(Calendar.DATE, 1);
        		availDateSet.add(dfDateTime.format(gc.getTime()));
        	}
        }
        List<String> availDates = new ArrayList<String>(availDateSet);
        Collections.sort(availDates);
        String[] finalResultArray = Arrays.asList(availDates.toArray()).toArray(new String[availDates.toArray().length]);
        String finalResult = "";
        for(int k=0; k<finalResultArray.length; k++){ //convert resulting array to string
        	if (k==0){
        		finalResult = finalResultArray[k];
        	}
        	else{
        		finalResult = finalResult + ", " + finalResultArray[k];
        	}
        }
        return finalResult;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		log("Running...");
		
		String[] amenities = {"Kitchen", "Wired Internet", "TV",  "Essentials", "Shampoo", "Heating", 
				"A/C", "Washer", "Dryer", "Free Parking", "WiFi", "Cable TV", "Breakfast", "Pets Allowed", 
				"Family/Kid Friendly", "Suitable for Events", "Smoking Allowed", "Wheelchair Accessible", 
				"Elevator", "Indoor Fireplace", "Buzzer/Wireless Intercom", "Doorman", "Pool", "Hot Tub", 
				"Gym", "24hr Check-in", "Hangers", "Iron", "Hair Dryer", "Laptop Friendly Workspace"};	
		String[] roomTypes = {"Entire Home/Apt", "Private Room", "Shared Room"};
		String[] propertyTypes = {"Apartment", "House", "Bed and Breakfast", "Boat", "Bungalow", "Camper/RV", 
				"Castle", "Condominium", "Cottage", "Dormitory", "Lighthouse", "Loft", "Other", 
				"Parking Space", "Tent", "Townhouse", "Villa"};
		
		String fileName = "Randomly Generated Properties.txt";
		int randomsRequested = -1;
		String sRandomsRequested = "";
		DecimalFormat listingIDFormat = new DecimalFormat("00000");
		String idStamp = "";
		String currentGeneratedListing = "";
		while (randomsRequested < 1 || randomsRequested > 99999){
			sRandomsRequested = JOptionPane.showInputDialog("How many listings do you want to generate?"
					+ " (Please enter a number between 1 and 99,999)");
			randomsRequested = Integer.parseInt(sRandomsRequested);
		}
		File file = new File(fileName);
		int fileVariant = 1;
		while (file.exists() == true){
			log(fileName + " already exists, checking if " + (fileName = "Randomly Generated Properties" + 
		"(" + fileVariant + ").txt") + " exists...");
			file = new File(fileName);
			fileVariant++;
		}
		try{
	        log("Making new file named " + fileName + "...");
	        file.createNewFile();
			PrintWriter writer = new PrintWriter(file);
			log("Generating entries...");
			for(int i=0; i<randomsRequested; i++){
				idStamp = listingIDFormat.format(i);
				currentGeneratedListing = generateListing(amenities, roomTypes, propertyTypes);
				currentGeneratedListing = idStamp + ", " + currentGeneratedListing;
				writer.println(currentGeneratedListing);
			}
			writer.close();
		}
	    catch (IOException e) 
	    {
	        // TODO Auto-generated catch block
	        e.printStackTrace();
	        System.out.println("File not found");
	        // if the file is not found then this error message is printed
	    } 
		
		log("Done!");
		
	}
}
